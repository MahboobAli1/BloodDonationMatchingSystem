-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2025 at 01:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blooddonation`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(121, 'admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `blood_tests`
--

CREATE TABLE `blood_tests` (
  `id` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `tested_by` varchar(100) DEFAULT NULL,
  `hiv` varchar(10) DEFAULT 'Unknown',
  `hbv` varchar(10) DEFAULT 'Unknown',
  `hcv` varchar(10) DEFAULT 'Unknown',
  `syphilis` varchar(10) DEFAULT 'Unknown',
  `malaria` varchar(10) DEFAULT 'Unknown',
  `dengue` varchar(10) DEFAULT 'Unknown',
  `htlv` varchar(10) DEFAULT 'Unknown',
  `test_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blood_tests`
--

INSERT INTO `blood_tests` (`id`, `donor_id`, `tested_by`, `hiv`, `hbv`, `hcv`, `syphilis`, `malaria`, `dengue`, `htlv`, `test_date`, `notes`) VALUES
(1, 1, 'f', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-16 20:56:34', ''),
(2, 3, 'ali', 'Positive', 'Negative', 'Positive', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-16 21:21:04', ''),
(3, 7, 'Azad', 'Positive', 'Negative', 'Negative', 'Positive', 'Negative', 'Negative', 'Negative', '2025-11-17 10:31:42', ''),
(4, 7, '', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-17 10:32:00', ''),
(5, 8, 'xyz', 'Negative', 'Negative', 'Positive', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-17 10:55:20', ''),
(6, 9, 'dr sindh lab', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-17 17:26:07', ''),
(7, 33, 'ali', 'Negative', 'Negative', 'Negative', 'Positive', 'Negative', 'Negative', 'Negative', '2025-11-19 13:02:46', ''),
(8, 32, 'ahmed', 'Negative', 'Positive', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 13:05:04', ''),
(9, 34, 'musbah', 'Negative', 'Negative', 'Negative', 'Positive', 'Negative', 'Negative', 'Negative', '2025-11-19 13:06:24', ''),
(10, 35, 'dd', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 13:14:57', ''),
(11, 35, 'ds', 'Positive', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 13:15:23', ''),
(12, 37, 'df', 'Negative', 'Negative', 'Positive', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 13:17:42', ''),
(13, 38, 'musbah', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 14:50:04', ''),
(14, 41, 'dr.abc', 'Positive', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 15:32:54', 'just one'),
(15, 48, 'sdas', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 20:55:13', ''),
(16, 48, 'df', 'Positive', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 20:55:29', ''),
(17, 45, 'dfsdf', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 20:56:02', ''),
(18, 45, 'dfds', 'Positive', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-19 20:56:17', ''),
(19, 32, 'dgf', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-20 12:54:28', ''),
(20, 32, 'sdf', 'Positive', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-20 12:54:44', ''),
(21, 3, 'fgdgd', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-20 12:55:05', ''),
(22, 1, 'sdf', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', 'Negative', '2025-11-20 13:02:59', '');

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE `donors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `available` tinyint(1) DEFAULT 1,
  `distance` double DEFAULT NULL,
  `screen_status` varchar(20) DEFAULT 'Not Tested'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`id`, `name`, `blood_group`, `city`, `phone`, `available`, `distance`, `screen_status`) VALUES
(1, 'a', 'A+', 'sukkur', '0300', 0, 88, 'Non-reactive'),
(2, 'abc', 'B-', 'gambat', '0800', 1, 70, 'Not Tested'),
(3, 'musbah', 'A-', 'ranipur', '0900', 1, 30, 'Non-reactive'),
(4, 'aa', 'a-', 'aa', '00', 1, 0, 'Not Tested'),
(5, 'hanif', 'A+', 'ubauro', '0220', 0, 570, 'Not Tested'),
(6, 'sajid', 'A+', 'Ghotki', '0300', 0, 50, 'Not Tested'),
(7, 'Sajid', 'A+', 'Ghotki', '0300', 0, 40, 'Non-reactive'),
(8, 'afsia', 'B+', 'ghotki', '998', 0, 0, 'Reactive'),
(9, 'Yasir', 'B+', 'Ubauiro', '03048664006', 0, 135, 'Non-reactive'),
(10, 'Niaz', 'A+', 'mirpurmathelo', '088', 0, 100, 'Not Tested'),
(11, 'q', 'A+', 'ss', '0300', 0, 30, 'Not Tested'),
(12, 'ww', 'A+', 'iii', '0300', 0, 30, 'Not Tested'),
(13, 'ali', 'O+', 'larkana', '030040050', 0, 80, 'Not Tested'),
(14, 'abcd', 'O-', 'karachi', '0700', 0, 400, 'Not Tested'),
(15, 'Asad', 'B+', 'larkana', '09000', 0, 60, 'Not Tested'),
(16, 'ghulam', 'B+', 'chak', '0500', 0, 30, 'Not Tested'),
(17, 'Ali', 'A+', 'sukk', '0400', 0, 30, 'Not Tested'),
(18, 'ali', 'B+', 'Sukkur', '0400', 0, 50, 'Not Tested'),
(19, 'ad', 'B+', 'sukk', '0300', 0, 40, 'Not Tested'),
(20, 'Sajjad', 'B+', 'ranipur', '04000', 0, 60, 'Not Tested'),
(21, 'Ahmed', 'B+', 'ghotki', '030', 0, 50, 'Not Tested'),
(22, 'musbah', 'B+', 'ranipur', '0400', 0, 40, 'Not Tested'),
(23, 'Asad', 'A+', 'sukkur', '0500', 0, 70, 'Not Tested'),
(24, 'aaa', 'A+', 'unn', '000000', 0, 0, 'Not Tested'),
(25, 'hhhh', 'B+', 'dfsdf', 'fsddsf', 0, 0, 'Not Tested'),
(26, 'dadfhdsjfh', 'O+', 'fgdg', '0000', 0, 0, 'Not Tested'),
(27, 'dfsdf', 'A+', 'dfgf', 'dfgf', 0, 0, 'Not Tested'),
(28, 'Ali', 'A+', 'sukur', '0800', 0, 0, 'Not Tested'),
(29, 'Basheer', 'B+', 'Ghotki', '0300000', 0, 0, 'Not Tested'),
(30, 'asad', 'A+', 'dsc', '00', 0, 0, 'Not Tested'),
(31, 'fsd', 'B+', 'wer', 'ewr', 0, 0, 'Not Tested'),
(32, 'dfasdf', 'B+', 'rtre', '44', 0, 0, 'Reactive'),
(33, 'qe', 'A+', 'erw', 'wer', 0, 0, 'Reactive'),
(34, 'asd', 'O-', 'ewf', 'gdfg', 0, 0, 'Reactive'),
(35, 'qwdfq', 'A+', 'efew', '5654', 0, 0, 'Reactive'),
(36, 'sadasd', 'O-', 'asfd', '050', 1, 0, 'Not Tested'),
(37, 'fsf', 'A+', 'feerf', '8654', 0, 0, 'Reactive'),
(38, 'azad', 'A+', 'sukkur', '0900', 0, 0, 'Non-reactive'),
(39, 'asad', 'A+', 'sukkur', '0300', 0, 0, 'Not Tested'),
(40, 'Yasir', 'B+', 'Ubauro', '03048664006', 1, 135, 'Not Tested'),
(41, 'mehmood', 'A+', 'multan', '00', 0, 400, 'Reactive'),
(42, 'adfdsf', 'A+', 'dgdfg', '757', 0, 60, 'Not Tested'),
(43, 'dsaef', 'A+', 'erger', '056545', 0, 70, 'Not Tested'),
(44, 'tergter', 'A+', 'fgfdg', 'dhg', 0, 80, 'Not Tested'),
(45, 'dfsdf', 'O+', 'sukkur', 'gerg', 0, 30, 'Reactive'),
(46, 'dsas', 'O+', 'sdd', '06567', 0, 20, 'Not Tested'),
(47, 'asdsa', 'O+', 'dgfdg', '546', 0, 10, 'Not Tested'),
(48, 'Ahmed', 'O+', 'Sukkur', '043304', 0, 33, 'Reactive'),
(49, 'Ali', 'A+', 'dsfsdf', 'sdfsd', 0, 30, 'Not Tested'),
(50, 'sdge', 'A+', 'sdgs', 'sdg', 0, 0, 'Not Tested'),
(51, 'sgfsg', 'A+', 'sdgs', 'egw', 0, 0, 'Not Tested'),
(52, 'sdsdf', 'A+', 'sdf', 'wegewg', 0, 0, 'Not Tested');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `patient_name` varchar(100) DEFAULT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `hospital` varchar(150) DEFAULT NULL,
  `urgency` varchar(10) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'PENDING',
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `distance` double DEFAULT NULL,
  `donor_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `patient_name`, `blood_group`, `city`, `hospital`, `urgency`, `status`, `createdAt`, `distance`, `donor_id`) VALUES
(1, 'ali', 'B+', 'sukk', 'nicvd', 'Low', 'Fulfilled', '2025-11-15 11:45:15', 0, 8),
(2, 'abcd', 'B-', 'sukkur', 'bb', 'Medium', 'Fulfilled', '2025-11-16 15:25:19', 40, NULL),
(3, 'ddd', 'A-', 'sukkur', 'hh', 'High', 'Fulfilled', '2025-11-16 15:46:31', 10, NULL),
(4, 'bb', 'b+', 'bb', 'bbb', 'Low', 'Fulfilled', '2025-11-16 16:07:37', 0, 8),
(5, 'muhammad', 'A+', 'shikarpur', 'hira', 'High', 'Fulfilled', '2025-11-16 17:50:35', 22, 10),
(6, 'basheer', 'A+', 'ghotki', 'nicvd', 'Medium', 'Fulfilled', '2025-11-16 18:22:36', 20, NULL),
(7, 'Shakeel', 'A+', 'sukkur', 'hira', 'Medium', 'Fulfilled', '2025-11-17 10:31:00', 10, NULL),
(8, 'afridi', 'B+', 'sukkur', 'nicvid', 'Medium', 'Fulfilled', '2025-11-17 10:53:00', 70, NULL),
(9, 'Mahboob', 'B+', 'Mirpur', 'civil hospital', 'Medium', 'Fulfilled', '2025-11-17 17:25:07', 78, NULL),
(10, 'wafa', 'A+', 'Sukkur', 'xyz', 'High', 'Fulfilled', '2025-11-17 17:30:24', 0, NULL),
(11, 'ff', 'A+', 'ee', 'ee', 'Low', 'Fulfilled', '2025-11-17 18:33:49', 20, 11),
(13, 'aqeel', 'O+', 'rustam', 'RiverCity', 'Low', 'Fulfilled', '2025-11-17 19:31:52', 50, 13),
(14, 'waseem', 'O-', 'jacobabad', 'hospital', 'Low', 'Fulfilled', '2025-11-17 20:23:24', 300, 14),
(15, 'habib', 'A+', 'dadu', 'gims', 'Low', 'Fulfilled', '2025-11-17 20:25:40', 80, 7),
(16, 'salman', 'A+', 'sukkur', 'nicvd', 'Low', 'Fulfilled', '2025-11-17 20:27:09', 70, 6),
(17, 'Asif', 'A+', 'ghotki', 'hira', 'Low', 'Fulfilled', '2025-11-17 20:27:41', 80, 1),
(18, 'suhail', 'B+', 'sukkur', 'abcd', 'Low', 'Fulfilled', '2025-11-17 20:28:43', 40, 15),
(19, 'dilawar', 'O-', 'A+', 'gg', 'Low', 'Fulfilled', '2025-11-17 20:29:21', 30, 5),
(20, 'Ahmed', 'B+', 'gambat', 'gims', 'Low', 'Fulfilled', '2025-11-17 20:30:01', 50, 9),
(21, 'asad', 'B+', 'ghotki', 'uu', 'Low', 'Fulfilled', '2025-11-17 20:31:16', 40, 16),
(22, 'hasan', 'B+', 'ranipur', 'hira', 'High', 'Fulfilled', '2025-11-17 20:34:39', 30, 16),
(23, 'aaa', 'A+', 'dd', 'ddd', 'Low', 'Fulfilled', '2025-11-17 21:10:32', 80, 17),
(24, 'halar', 'B+', 'sukkur', 'river', 'Low', 'Fulfilled', '2025-11-17 21:25:10', 40, 20),
(25, 'Hanif', 'B+', 'ghotki', 'hira', 'Medium', 'Fulfilled', '2025-11-18 18:59:29', 50, 21),
(26, 'suhail', 'B+', 'sukkur', 'nicvd', 'Low', 'Fulfilled', '2025-11-18 19:13:33', 50, 22),
(27, 'Ahmed', 'B+', 'ghotki', 'hira', 'Low', 'Fulfilled', '2025-11-18 19:40:51', 100, 23),
(28, 'aaa', 'B+', 'dfsf', 'dsfd', 'Low', 'Fulfilled', '2025-11-18 19:51:04', 0, 25),
(29, 'jjjj', 'A+', 'dasf', 'dfsdf', 'Low', 'Fulfilled', '2025-11-18 19:53:57', 0, 24),
(30, 'gdfg', 'O+', 'gfdg', 'gret', 'Low', 'Fulfilled', '2025-11-18 19:55:21', 0, 26),
(31, 'safdsaf', 'A+', 'fsd', 'dsfsdf', 'Low', 'Fulfilled', '2025-11-18 19:59:01', 0, 27),
(32, 'Hasnain', 'O+', 'sukkur', 'river', 'Low', 'Fulfilled', '2025-11-19 11:07:23', 0, 28),
(33, 'Lakhan', 'A+', 'ghotki', 'hira', 'Low', 'Fulfilled', '2025-11-19 11:23:25', 30, 29),
(34, 'sdf', 'B+', 'dsf', 'dfs', 'Low', 'Fulfilled', '2025-11-19 11:40:20', 0, 31),
(35, 'erwer', 'A+', 'egre', 'rg', 'Low', 'Fulfilled', '2025-11-19 12:54:18', 0, 30),
(36, 'qrwe', 'A+', 'wf', 'we', 'Low', 'Fulfilled', '2025-11-19 12:55:08', 0, 33),
(37, 'dfgef', 'O-', 'werwe', 'ertert', 'Low', 'Fulfilled', '2025-11-19 13:05:58', 0, 34),
(38, 'rw4t34', 'A+', '34t3', 'treger', 'Low', 'Fulfilled', '2025-11-19 13:14:36', 0, 38),
(39, 'Akbar', 'A+', 'karachi', 'xyz', 'High', 'Fulfilled', '2025-11-19 15:30:55', 0, 39),
(40, 'Abc', 'A+', 'sss', 'ssdd', 'Low', 'Fulfilled', '2025-11-19 19:50:48', 50, 43),
(41, 'ff', 'A+', 'fdsdf', 'dfgdsg', 'Medium', 'Fulfilled', '2025-11-19 19:51:08', 50, 42),
(42, 'fsdf', 'A+', 'fsg', 'fgdf', 'High', 'Fulfilled', '2025-11-19 19:51:27', 50, 44),
(43, 'ASD', 'O+', 'sdf', 'fsdf', 'Low', 'Fulfilled', '2025-11-19 19:54:53', 50, 47),
(44, 'asdsa', 'O+', 'ddsf', 'sdfds', 'Low', 'Fulfilled', '2025-11-19 20:52:47', 40, 46),
(45, 'ALI', 'A+', 'sukkur', 'dfds', 'High', 'Fulfilled', '2025-11-19 20:54:24', 30, 51),
(46, 'dfdsf', 'A+', 'dsfds', 'dsgfd', 'Low', 'Pending', '2025-11-19 21:17:40', 10, NULL),
(47, 'erwer', 'A+', 'fdsdgre', 'grwe', 'Medium', 'Fulfilled', '2025-11-19 21:17:55', 50, 49),
(49, 'sadfasas', 'A+', 'asf', 'asf', 'Low', 'Fulfilled', '2025-11-20 12:17:38', 0, 52);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `blood_tests`
--
ALTER TABLE `blood_tests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `donor_id` (`donor_id`);

--
-- Indexes for table `donors`
--
ALTER TABLE `donors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `blood_tests`
--
ALTER TABLE `blood_tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `donors`
--
ALTER TABLE `donors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blood_tests`
--
ALTER TABLE `blood_tests`
  ADD CONSTRAINT `blood_tests_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `donors` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
