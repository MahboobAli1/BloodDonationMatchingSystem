/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Azad Ali
 */
 import java.sql.*;
import java.util.ArrayList;
class tblDonors {
   



    // Donor fields
    private int id;
    private String name;
    private String bloodGroup;
    private String address;
    private String phone;
    private String screen_status;

    // Constructors
    public tblDonors() {}

    public tblDonors(int id, String name, String bloodGroup, String address, String phone,String screen_status) {
        this.id = id;
        this.name = name;
        this.bloodGroup = bloodGroup;
        this.address = address;
        this.phone = phone;
        this.screen_status = screen_status;
    }

    // ------------ GETTERS & SETTERS ------------
    public int getId() { return id; }
    public String getName() { return name; }
    public String getBloodGroup() { return bloodGroup; }
    public String getAddress() { return address; }
    public String getPhone() { return phone; }
// Getter & Setter
public String getScreen_status() { return screen_status; }
public void setScreen_status(String screen_status) { this.screen_status = screen_status; }
    public void setName(String name) { this.name = name; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }
    public void setAddress(String address) { this.address = address; }
    public void setPhone(String phone) { this.phone = phone; }

    // ------------ INSERT NEW DONOR ------------
   public static boolean addDonor(String name, String bloodGroup, String address, String phone, String screenStatus) {
    String sql = "INSERT INTO donors (name, blood_group, address, phone, screen_status) VALUES (?, ?, ?, ?, ?)";

    try (Connection con = DatabaseManager.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, name);
        pst.setString(2, bloodGroup);
        pst.setString(3, address);
        pst.setString(4, phone);
        pst.setString(5, screenStatus);

        return pst.executeUpdate() > 0;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}


    // ------------ FETCH ALL DONORS ------------
    public static ArrayList<tblDonors> getAllDonors() {
        ArrayList<tblDonors> list = new ArrayList<>();
        String sql = "SELECT * FROM donors";

        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                tblDonors d = new tblDonors(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("blood_group"),
                        rs.getString("address"),
                        rs.getString("phone"),
                         rs.getString("screen_status")
                );
                list.add(d);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    
   public static boolean updateDonor(int id, String name, String bloodGroup, String address, String phone, String screenStatus) {
    String sql = "UPDATE donors SET name=?, blood_group=?, address=?, phone=?, screen_status=? WHERE id=?";

    try (Connection con = DatabaseManager.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, name);
        pst.setString(2, bloodGroup);
        pst.setString(3, address);
        pst.setString(4, phone);
        pst.setString(5, screenStatus);
        pst.setInt(6, id);

        return pst.executeUpdate() > 0;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}


    // ------------ DELETE DONOR ------------
    public static boolean deleteDonor(int id) {
        String sql = "DELETE FROM donors WHERE id=?";

        try (Connection con = DatabaseManager.getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, id);
            return pst.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    
}
