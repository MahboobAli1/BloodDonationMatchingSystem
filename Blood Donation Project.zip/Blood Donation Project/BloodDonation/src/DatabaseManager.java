/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Azad Ali
 */


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3306/blooddonation";
    private static final String USER = "root";  // change if needed
    private static final String PASSWORD = "";  // add your MySQL password if any

    // 🔹 Establish connection
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found.");
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    
    // Insert donor
    public boolean insertDonor(String name, String blood, String city, String phone, double distance) {
        String sql = "INSERT INTO donors (name, blood_group, city, phone, distance_km) VALUES (?, ?, ?, ?, ?)";
        try (Connection c = getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, name);
            p.setString(2, blood);
            p.setString(3, city);
            p.setString(4, phone);
            p.setDouble(5, distance);
            return p.executeUpdate() == 1;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Insert request
    public boolean insertRequest(String patientName, String requiredBlood, String city, String hospital, double distance, String urgency) {
        String sql = "INSERT INTO requests (patient_name, required_blood, city, hospital, distance_km, urgency, status) VALUES (?, ?, ?, ?, ?, ?, 'PENDING')";
        try (Connection c = getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1, patientName);
            p.setString(2, requiredBlood);
            p.setString(3, city);
            p.setString(4, hospital);
            p.setDouble(5, distance);
            p.setString(6, urgency);
            return p.executeUpdate() == 1;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Simple donor search by blood and/or city
    public ResultSet searchDonors(String bloodFilter, String cityFilter) throws SQLException {
        Connection c = getConnection();
        StringBuilder sql = new StringBuilder("SELECT id, name, blood_group, city, phone, distance_km FROM donors WHERE 1=1 ");
        if (bloodFilter != null && !bloodFilter.trim().isEmpty()) sql.append(" AND blood_group LIKE ? ");
        if (cityFilter != null && !cityFilter.trim().isEmpty()) sql.append(" AND city LIKE ? ");
        PreparedStatement p = c.prepareStatement(sql.toString());
        int idx = 1;
        if (bloodFilter != null && !bloodFilter.trim().isEmpty()) p.setString(idx++, "%" + bloodFilter.trim() + "%");
        if (cityFilter != null && !cityFilter.trim().isEmpty()) p.setString(idx++, "%" + cityFilter.trim() + "%");
        return p.executeQuery(); // caller must close ResultSet and connection
    }

    // Simple request search by blood and/or city
    public ResultSet searchRequests(String bloodFilter, String cityFilter) throws SQLException {
        Connection c = getConnection();
        StringBuilder sql = new StringBuilder("SELECT id, patient_name, required_blood, city, hospital, distance_km, urgency, status FROM requests WHERE 1=1 ");
        if (bloodFilter != null && !bloodFilter.trim().isEmpty()) sql.append(" AND required_blood LIKE ? ");
        if (cityFilter != null && !cityFilter.trim().isEmpty()) sql.append(" AND city LIKE ? ");
        PreparedStatement p = c.prepareStatement(sql.toString());
        int idx = 1;
        if (bloodFilter != null && !bloodFilter.trim().isEmpty()) p.setString(idx++, "%" + bloodFilter.trim() + "%");
        if (cityFilter != null && !cityFilter.trim().isEmpty()) p.setString(idx++, "%" + cityFilter.trim() + "%");
        return p.executeQuery();
    }

    // Get next pending request (for admin automated queue)
    public ResultSet getNextPendingRequest() throws SQLException {
        Connection c = getConnection();
        String sql = "SELECT id, patient_name, required_blood, city, hospital, distance_km, urgency FROM requests WHERE status = 'PENDING' ORDER BY FIELD(urgency,'High','Medium','Low') DESC, id ASC LIMIT 1";
        PreparedStatement p = c.prepareStatement(sql);
        return p.executeQuery();
    }

    // Attempt to find nearest donor for a requested blood type and city (simple)
    public ResultSet findMatchingDonors(String bloodGroup, String city) throws SQLException {
        Connection c = getConnection();
        String sql = "SELECT id, name, blood_group, city, phone, distance_km FROM donors WHERE blood_group = ? AND city = ? ORDER BY distance_km ASC";
        PreparedStatement p = c.prepareStatement(sql);
        p.setString(1, bloodGroup);
        p.setString(2, city);
        return p.executeQuery();
    }

    // Mark request as fulfilled and optionally record donor used (simple)
    public boolean fulfillRequest(int requestId, Integer donorId) {
        String sql = "UPDATE requests SET status = 'FULFILLED', fulfilled_by_donor_id = ? WHERE id = ?";
        try (Connection c = getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            if (donorId == null) p.setNull(1, Types.INTEGER);
            else p.setInt(1, donorId);
            p.setInt(2, requestId);
            return p.executeUpdate() == 1;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}

