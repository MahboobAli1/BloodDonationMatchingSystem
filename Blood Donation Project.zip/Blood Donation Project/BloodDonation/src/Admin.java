/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Azad Ali
 * 
 */
import java.awt.Image;
import java.util.Random;
import javax.swing.JOptionPane;

 
  import java.sql.*;
import javax.swing.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
 

  


public class Admin extends javax.swing.JFrame {

    public Admin() {
        initComponents();
        
        jButtonRefreshData1.addActionListener(evt -> {
    loadAdminData();
    loadTableData();
    loadDonorData();
    loadRequestsData();
});

        
        
         setBackgroundImage();
        this.setLocationRelativeTo(null);

        // ----- FULL SIZE BACKGROUND IMAGE -----
    ImageIcon icon = new ImageIcon(getClass().getResource("/images/bg.jpg"));
    Image img = icon.getImage();
    Image scaled = img.getScaledInstance(this.getWidth(), this.getHeight(), Image.SCALE_SMOOTH);

    JLabel background = new JLabel(new ImageIcon(scaled));
    background.setBounds(0, 0, this.getWidth(), this.getHeight());
    getContentPane().add(background);
    getContentPane().setComponentZOrder(background, getContentPane().getComponentCount() - 1);
        
        loadAdminData();
        loadTableData();
        loadDonorData();
        loadRequestsData();

        // Attach ActionListener to Fulfill Specific Request button
        jButtonFullfillSpecificRequests.addActionListener(evt -> manualFulfillment());

        // Optional: attach ActionListener to Process Next button
        jButtonProcessNext.addActionListener(evt -> processNextRequest());

        // Optional: attach ActionListener to Refresh Data button
        jButtonManualTest.addActionListener(evt -> {
            loadAdminData();
            loadTableData();
            loadDonorData();
        });
    }
    
    private void setBackgroundImage() {
    ImageIcon icon = new ImageIcon(getClass().getResource("/images/bg.jpg"));
    JLabel background = new JLabel(icon);
    background.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
    
    // Move all components in front of background
    this.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));

    // Make content pane transparent
    ((JPanel) this.getContentPane()).setOpaque(false);
}

    
    
    
    private void openManualTestForm() {
    javax.swing.JTextField donorIdField = new javax.swing.JTextField();
    javax.swing.JTextField testerField = new javax.swing.JTextField();
    javax.swing.JTextField notesField = new javax.swing.JTextField();

    String[] options = {"Negative", "Positive"};

    javax.swing.JComboBox<String> hivBox = new javax.swing.JComboBox<>(options);
    javax.swing.JComboBox<String> hbvBox = new javax.swing.JComboBox<>(options);
    javax.swing.JComboBox<String> hcvBox = new javax.swing.JComboBox<>(options);
    javax.swing.JComboBox<String> syphilisBox = new javax.swing.JComboBox<>(options);
    javax.swing.JComboBox<String> malariaBox = new javax.swing.JComboBox<>(options);
    javax.swing.JComboBox<String> dengueBox = new javax.swing.JComboBox<>(options);
    javax.swing.JComboBox<String> htlvBox = new javax.swing.JComboBox<>(options);

    Object[] form = {
        "Donor ID:", donorIdField,
        "Tested By:", testerField,
        "HIV:", hivBox,
        "Hepatitis B (HBV):", hbvBox,
        "Hepatitis C (HCV):", hcvBox,
        "Syphilis:", syphilisBox,
        "Malaria:", malariaBox,
        "Dengue:", dengueBox,
        "HTLV:", htlvBox,
        "Notes:", notesField
    };

    int result = javax.swing.JOptionPane.showConfirmDialog(this, form, 
            "Enter Blood Test Results", javax.swing.JOptionPane.OK_CANCEL_OPTION);

    if (result == javax.swing.JOptionPane.OK_OPTION) {

    // --- FIX: validate donor ID ---
    String donorIdText = donorIdField.getText().trim();
    if (donorIdText.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Donor ID cannot be empty!");
        return;
    }

    int donorId;
    try {
        donorId = Integer.parseInt(donorIdText);
    } catch (NumberFormatException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Donor ID must be a valid number!");
        return;
    }
    // --- END FIX ---

    String tester = testerField.getText();
    String notes = notesField.getText();

    saveManualTest(
        donorId, tester,
        hivBox.getSelectedItem().toString(),
        hbvBox.getSelectedItem().toString(),
        hcvBox.getSelectedItem().toString(),
        syphilisBox.getSelectedItem().toString(),
        malariaBox.getSelectedItem().toString(),
        dengueBox.getSelectedItem().toString(),
        htlvBox.getSelectedItem().toString(),
        notes
    );
}

}

    
    
    
    private void loadRequestsData() {
    DefaultTableModel model = (DefaultTableModel) jTableRequests.getModel();
    model.setRowCount(0);

    String sql = "SELECT id, patient_name, blood_group, city, hospital, urgency, status, distance FROM requests";

    try (Connection con = DatabaseManager.getConnection();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("id"),
                rs.getString("patient_name"),
                rs.getString("blood_group"),
                rs.getString("city"),
                rs.getString("hospital"),
                rs.getString("urgency"),
                rs.getString("status"),
                rs.getInt("distance")
            });
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
}

    
    
    
    
    
    
    
    private void saveManualTest(int donorId, String tester,
        String hiv, String hbv, String hcv, String syphilis,
        String malaria, String dengue, String htlv, String notes) {

    boolean anyPositive = hiv.equals("Positive") ||
                          hbv.equals("Positive") ||
                          hcv.equals("Positive") ||
                          syphilis.equals("Positive") ||
                          malaria.equals("Positive") ||
                          dengue.equals("Positive") ||
                          htlv.equals("Positive");

    String screenStatus = anyPositive ? "Reactive" : "Non-reactive";

    String sql = "INSERT INTO blood_tests (donor_id, tested_by, hiv, hbv, hcv, syphilis, malaria, dengue, htlv, notes) "
               + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try (Connection con = DatabaseManager.getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setInt(1, donorId);
        pst.setString(2, tester);
        pst.setString(3, hiv);
        pst.setString(4, hbv);
        pst.setString(5, hcv);
        pst.setString(6, syphilis);
        pst.setString(7, malaria);
        pst.setString(8, dengue);
        pst.setString(9, htlv);
        pst.setString(10, notes);

        pst.executeUpdate();

        // Update donor status
        String update = "UPDATE donors SET screen_status=? WHERE id=?";
        try (PreparedStatement upd = con.prepareStatement(update)) {
            upd.setString(1, screenStatus);
            upd.setInt(2, donorId);
            upd.executeUpdate();
        }
        
        
        
        // If Reactive → block donor automatically
if (screenStatus.equals("Reactive")) {
    String block = "UPDATE donors SET available=0 WHERE id=?";
    try (PreparedStatement pstBlock = con.prepareStatement(block)) {
        pstBlock.setInt(1, donorId);
        pstBlock.executeUpdate();
    }
}


        javax.swing.JOptionPane.showMessageDialog(this, 
                "Test results saved.\nOverall Status: " + screenStatus);

    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
}

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  /*  private void testBlood() {
    String donorIdStr = JOptionPane.showInputDialog(this, "Enter Donor ID to test:");
    if (donorIdStr == null || donorIdStr.isEmpty()) return;

    int donorId;
    try {
        donorId = Integer.parseInt(donorIdStr);
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this, "Invalid ID!");
        return;
    }

    try (Connection con = DatabaseManager.getConnection()) {
        // Check if donor exists
        PreparedStatement pst = con.prepareStatement("SELECT name FROM donors WHERE id=?");
        pst.setInt(1, donorId);
        ResultSet rs = pst.executeQuery();

        if (!rs.next()) {
            JOptionPane.showMessageDialog(this, "Donor not found!");
            return;
        }

        String donorName = rs.getString("name");

        // Simulate disease test
        String[] diseases = {"AIDS", "Hepatitis B", "Hepatitis C", "Syphilis", "Malaria"};
        Random rand = new Random();
        String result = (rand.nextBoolean()) ? "Negative" : "Positive for " + diseases[rand.nextInt(diseases.length)];

        JOptionPane.showMessageDialog(this, "Blood test for " + donorName + " (ID: " + donorId + "):\n" + result);

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        ex.printStackTrace();
    }
}

    */
    
    
    
    
    
    
    

private void loadDonorData() {
    DefaultTableModel model = (DefaultTableModel) jTableDonors.getModel();
    model.setRowCount(0);

    String sql = "SELECT id, name, blood_group, city, phone, available, distance, screen_status FROM donors";

    try (Connection con = DatabaseManager.getConnection();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("blood_group"),
                rs.getString("city"),
                rs.getString("phone"),
                rs.getString("available"),
                rs.getInt("distance"),
                rs.getString("screen_status")
            });
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading donors: " + e.getMessage());
    }
}


    
    
    
    
 private void loadTableData() {
    DefaultTableModel model = (DefaultTableModel) jTableDonors.getModel();
    model.setRowCount(0);

    String sql = "SELECT id, name, blood_group, city, phone, available, distance, screen_status FROM donors";

    try (Connection con = DatabaseManager.getConnection();
         PreparedStatement pst = con.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("blood_group"),
                rs.getString("city"),
                rs.getString("phone"),
                rs.getString("available"),
                rs.getInt("distance"),
                rs.getString("screen_status")
            });
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
}


    
    
    
    // ------------------- LOAD ADMIN DATA (QUEUE STATUS) -------------------
    private void loadAdminData() {
        try (Connection con = DatabaseManager.getConnection();
             Statement st = con.createStatement()) {

            ResultSet rs = st.executeQuery("SELECT COUNT(*) AS cnt FROM requests WHERE status='Pending'");
            if (rs.next()) {
                setTitle("Admin Panel - Pending Requests: " + rs.getInt("cnt"));
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading admin data: " + ex.getMessage());
        }
    }

    // ------------------- PROCESS NEXT AUTOMATIC REQUEST -------------------
private void processNextRequest() {
    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/blooddonation", "root", "");

        // 1. Get highest priority pending request
       String getRequest = "SELECT * FROM requests WHERE status='Pending' " +
                    "ORDER BY CASE urgency " +
                    "WHEN 'High' THEN 3 " +
                    "WHEN 'Medium' THEN 2 " +
                    "WHEN 'Low' THEN 1 END DESC, distance ASC LIMIT 1";

        PreparedStatement pst1 = con.prepareStatement(getRequest);
        ResultSet rs1 = pst1.executeQuery();

        if (!rs1.next()) {
            JOptionPane.showMessageDialog(this, "No pending requests.");
            return;
        }

        int reqId = rs1.getInt("id");
        String reqBlood = rs1.getString("blood_group");

        // 2. Find matching donor
        String getDonor = "SELECT * FROM donors WHERE available = 1 AND blood_group = ? ORDER BY distance ASC LIMIT 1";
        PreparedStatement pst2 = con.prepareStatement(getDonor);
        pst2.setString(1, reqBlood);
        ResultSet rs2 = pst2.executeQuery();

        if (!rs2.next()) {
            JOptionPane.showMessageDialog(this, "No matching donor found!");
            return;
        }

        int donorId = rs2.getInt("id");

        // 3. Update request
        String updReq = "UPDATE requests SET status='Fulfilled', donor_id=? WHERE id=?";
        PreparedStatement pst3 = con.prepareStatement(updReq);
        pst3.setInt(1, donorId);
        pst3.setInt(2, reqId);
        pst3.executeUpdate();

        // 4. Update donor
        String updDonor = "UPDATE donors SET available=0 WHERE id=?";
        PreparedStatement pst4 = con.prepareStatement(updDonor);
        pst4.setInt(1, donorId);
        pst4.executeUpdate();

        // 5. Refresh the tables
        loadRequestsData();
        loadDonorData();

        JOptionPane.showMessageDialog(this, "Request fulfilled automatically!");

    } catch (Exception ex) {
        ex.printStackTrace();
    }
}



    // ------------------- MANUAL OVERRIDE (SPECIFIC REQUEST + DONOR) -------------------
private void manualFulfillment() {

    String reqId = jTextFieldRequestID.getText().trim();
    String donorId = jTextFieldselectedDonorId.getText().trim();

    if (reqId.isEmpty() || donorId.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Enter both Request ID and Donor ID!");
        return;
    }

    try (Connection con = DatabaseManager.getConnection()) {

        // ===============================
        // 🔥 PASTE THIS NEW BLOCK HERE
        // ===============================

        // 1. Check request status + blood group
        PreparedStatement pstCheckReq = con.prepareStatement(
                "SELECT blood_group, status FROM requests WHERE id=?");
        pstCheckReq.setInt(1, Integer.parseInt(reqId));
        ResultSet rsReq = pstCheckReq.executeQuery();

        if (!rsReq.next()) {
            JOptionPane.showMessageDialog(this, "Invalid Request ID!");
            return;
        }

        // Already fulfilled → stop
        if (rsReq.getString("status").equals("Fulfilled")) {
            JOptionPane.showMessageDialog(this, "This request is already fulfilled!");
            return;
        }

        String reqBlood = rsReq.getString("blood_group");

        // 2. Check donor availability + blood group
        PreparedStatement pstDonCheck = con.prepareStatement(
                "SELECT blood_group, available FROM donors WHERE id=?");
        pstDonCheck.setInt(1, Integer.parseInt(donorId));
        ResultSet rsDon = pstDonCheck.executeQuery();

        if (!rsDon.next()) {
            JOptionPane.showMessageDialog(this, "Invalid Donor ID!");
            return;
        }

        // Donor unavailable
        if (rsDon.getInt("available") == 0) {
            JOptionPane.showMessageDialog(this, "This donor is already unavailable!");
            return;
        }

        // Blood group mismatch
        if (!rsDon.getString("blood_group").equals(reqBlood)) {
            JOptionPane.showMessageDialog(this,
                    "Donor blood group does NOT match the request!");
            return;
        }

        // ===============================
        // END OF NEW BLOCK
        // ===============================


        // ---- Your old code continues below ----

        // Update request as fulfilled
        PreparedStatement pst = con.prepareStatement(
                "UPDATE requests SET status='Fulfilled', donor_id=? WHERE id=?");
        pst.setInt(1, Integer.parseInt(donorId));
        pst.setInt(2, Integer.parseInt(reqId));
        int updated = pst.executeUpdate();

        if (updated > 0) {
            // Make donor unavailable
            PreparedStatement pstDonorUpdate = con.prepareStatement(
                    "UPDATE donors SET available=0 WHERE id=?");
            pstDonorUpdate.setInt(1, Integer.parseInt(donorId));
            pstDonorUpdate.executeUpdate();

            JOptionPane.showMessageDialog(this, "Request fulfilled successfully!");

            loadTableData();
            loadDonorData();
            loadAdminData();

            jTextFieldRequestID.setText("");
            jTextFieldselectedDonorId.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Invalid Request ID!");
        }

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }
}



    // ------------------- BUTTON HANDLERS -------------------



    private void jButtonProcessNextActionPerformed(java.awt.event.ActionEvent evt) {
        processNextRequest();
        loadRequestsData();
    }

    private void jButtonRefreshDataActionPerformed(java.awt.event.ActionEvent evt) {
        loadAdminData();
    }


    // --------------- AUTOGENERATED CODE BELOW (NO CHANGES) -------------------
    @SuppressWarnings("unchecked")
 

    // ----------- MAIN ----------
    

    
    
    // ---------- VARIABLES ----------
   



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
   
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButtonAdminDonor = new javax.swing.JButton();
        jButtonAdminRequests = new javax.swing.JButton();
        jButtonProcessNext = new javax.swing.JButton();
        jButtonManualTest = new javax.swing.JButton();
        jButtonFullfillSpecificRequests = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableRequests = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableDonors = new javax.swing.JTable();
        jButtonRefreshData1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jTextFieldRequestID = new javax.swing.JTextField();
        jTextFieldselectedDonorId = new javax.swing.JTextField();
        jLabelManualFullfillment = new javax.swing.JLabel();
        jLabelRequestedId = new javax.swing.JLabel();
        jLabelDonorId = new javax.swing.JLabel();
        btnShowPendingAndAvailable = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 153, 153));

        jButtonAdminDonor.setBackground(new java.awt.Color(255, 153, 0));
        jButtonAdminDonor.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonAdminDonor.setText("Donor");
        jButtonAdminDonor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdminDonorActionPerformed(evt);
            }
        });

        jButtonAdminRequests.setBackground(new java.awt.Color(255, 153, 0));
        jButtonAdminRequests.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonAdminRequests.setText("Requests");
        jButtonAdminRequests.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAdminRequestsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButtonAdminDonor, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jButtonAdminRequests, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonAdminDonor, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonAdminRequests, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        jButtonProcessNext.setBackground(new java.awt.Color(255, 153, 0));
        jButtonProcessNext.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonProcessNext.setText("Process Next (Automated Queue)");

        jButtonManualTest.setBackground(new java.awt.Color(255, 153, 0));
        jButtonManualTest.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonManualTest.setText("Manual Test Entry");
        jButtonManualTest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonManualTestActionPerformed(evt);
            }
        });

        jButtonFullfillSpecificRequests.setBackground(new java.awt.Color(255, 153, 0));
        jButtonFullfillSpecificRequests.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonFullfillSpecificRequests.setText("Fullfill Specific Request");
        jButtonFullfillSpecificRequests.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFullfillSpecificRequestsActionPerformed(evt);
            }
        });

        jTableRequests.setBackground(new java.awt.Color(255, 204, 204));
        jTableRequests.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTableRequests.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "id", "patient_name", "blood_group", "city", "hospital", "urgency", "status", "distance"
            }
        ));
        jScrollPane1.setViewportView(jTableRequests);

        jTableDonors.setBackground(new java.awt.Color(255, 204, 204));
        jTableDonors.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTableDonors.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "id", "name", "blood_group", "city", "phone", "available", "distance", "screen_status"
            }
        ));
        jScrollPane2.setViewportView(jTableDonors);

        jButtonRefreshData1.setBackground(new java.awt.Color(255, 153, 0));
        jButtonRefreshData1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonRefreshData1.setText("Refresh Data");

        jPanel2.setBackground(new java.awt.Color(255, 204, 204));

        jLabel1.setBackground(new java.awt.Color(204, 153, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Donors Available");

        jLabel2.setBackground(new java.awt.Color(204, 153, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("Patients Available");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(219, 219, 219))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(255, 153, 153));

        jTextFieldRequestID.setBackground(new java.awt.Color(204, 255, 204));
        jTextFieldRequestID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldRequestIDActionPerformed(evt);
            }
        });

        jTextFieldselectedDonorId.setBackground(new java.awt.Color(204, 255, 204));

        jLabelManualFullfillment.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelManualFullfillment.setText("Manual Fullfillment (Admin Override)");

        jLabelRequestedId.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelRequestedId.setText("Selected Request ID:");

        jLabelDonorId.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabelDonorId.setText("Selected Donor ID:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelRequestedId)
                            .addComponent(jLabelDonorId, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(61, 61, 61)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextFieldRequestID, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextFieldselectedDonorId, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabelManualFullfillment, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabelManualFullfillment, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldRequestID, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelRequestedId, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldselectedDonorId, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelDonorId))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        btnShowPendingAndAvailable.setBackground(new java.awt.Color(255, 153, 0));
        btnShowPendingAndAvailable.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnShowPendingAndAvailable.setText("Show Pending & Available");
        btnShowPendingAndAvailable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowPendingAndAvailableActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(365, 365, 365)
                        .addComponent(jButtonFullfillSpecificRequests, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButtonProcessNext)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButtonRefreshData1, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButtonManualTest, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnShowPendingAndAvailable, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(55, 55, 55)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 531, Short.MAX_VALUE))
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(37, 37, 37))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnShowPendingAndAvailable, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButtonProcessNext, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButtonRefreshData1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButtonManualTest, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonFullfillSpecificRequests, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldRequestIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldRequestIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldRequestIDActionPerformed

    private void jButtonAdminDonorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdminDonorActionPerformed
        // TODO add your handling code here:
        this.dispose();
new Donor().setVisible(true);

    }//GEN-LAST:event_jButtonAdminDonorActionPerformed

    private void jButtonAdminRequestsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAdminRequestsActionPerformed
        // TODO add your handling code here:
        this.dispose();
new Requests().setVisible(true);

    }//GEN-LAST:event_jButtonAdminRequestsActionPerformed

    private void jButtonFullfillSpecificRequestsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFullfillSpecificRequestsActionPerformed
        // TODO add your handling code here:
        loadRequestsData();
    }//GEN-LAST:event_jButtonFullfillSpecificRequestsActionPerformed

    private void jButtonManualTestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonManualTestActionPerformed
   openManualTestForm();
   loadDonorData();
   // TODO add your handling code here:
        
    }//GEN-LAST:event_jButtonManualTestActionPerformed

    
    
    
    
private void loadPendingRequestsIntoTable(JTable table) {
    DefaultTableModel model = new DefaultTableModel();
    table.setModel(model);

    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/blooddonation", "root", "");
        String sql = "SELECT * FROM requests WHERE status='Pending'";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        ResultSetMetaData rsmd = rs.getMetaData();
        int cols = rsmd.getColumnCount();

        // Add columns
        for (int i = 1; i <= cols; i++) {
            model.addColumn(rsmd.getColumnName(i));
        }

        // Add rows
        while (rs.next()) {
            Object[] row = new Object[cols];
            for (int i = 0; i < cols; i++) {
                row[i] = rs.getObject(i + 1);
            }
            model.addRow(row);
        }

        con.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}

private void loadAvailableDonorsIntoTable(JTable table) {
    DefaultTableModel model = new DefaultTableModel();
    table.setModel(model);

    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/blooddonation", "root", "");
        String sql = "SELECT * FROM donors WHERE available > 0";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        ResultSetMetaData rsmd = rs.getMetaData();
        int cols = rsmd.getColumnCount();

        // Add columns
        for (int i = 1; i <= cols; i++) {
            model.addColumn(rsmd.getColumnName(i));
        }

        // Add rows
        while (rs.next()) {
            Object[] row = new Object[cols];
            for (int i = 0; i < cols; i++) {
                row[i] = rs.getObject(i + 1);
            }
            model.addRow(row);
        }

        con.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}


    private void btnShowPendingAndAvailableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowPendingAndAvailableActionPerformed
        // TODO add your handling code here:
        
                                     
    // Create new JFrame
    JFrame frame = new JFrame("Pending Requests & Available Donors");
    frame.setSize(900, 600);
    frame.setLocationRelativeTo(null);

    // Create two tables
    JTable requestsTable = new JTable();
    JTable donorsTable = new JTable();

    // Load data into tables
    loadPendingRequestsIntoTable(requestsTable);
    loadAvailableDonorsIntoTable(donorsTable);

    // Put tables in scroll panes
    JScrollPane scrollRequests = new JScrollPane(requestsTable);
    JScrollPane scrollDonors = new JScrollPane(donorsTable);

    // Layout
    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollRequests, scrollDonors);
    splitPane.setDividerLocation(450);

    frame.add(splitPane);
    frame.setVisible(true);


        
    }//GEN-LAST:event_btnShowPendingAndAvailableActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnShowPendingAndAvailable;
    private javax.swing.JButton jButtonAdminDonor;
    private javax.swing.JButton jButtonAdminRequests;
    private javax.swing.JButton jButtonFullfillSpecificRequests;
    private javax.swing.JButton jButtonManualTest;
    private javax.swing.JButton jButtonProcessNext;
    private javax.swing.JButton jButtonRefreshData1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelDonorId;
    private javax.swing.JLabel jLabelManualFullfillment;
    private javax.swing.JLabel jLabelRequestedId;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableDonors;
    private javax.swing.JTable jTableRequests;
    private javax.swing.JTextField jTextFieldRequestID;
    private javax.swing.JTextField jTextFieldselectedDonorId;
    // End of variables declaration//GEN-END:variables

   
}
